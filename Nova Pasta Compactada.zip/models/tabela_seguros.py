from flask import json

from database.connection import DatabaseConnection
import uuid

class TabelaSegurosModel:
    def __init__(self, db_path):
        self.db = DatabaseConnection(db_path)

    def inserir_dados(self, dados):
        """
        Insere dados na tabela Tabela_Seguros.
        :param dados: Dicionário com os dados a serem inseridos.
        """
        # Gerar um UUID
        dados['unique_id'] = str(uuid.uuid4())

        query = """
        INSERT INTO Tabela_Seguros (
            uuid, Codigo_Mediador, Nome_Mediador, Email_Mediador, Telefone_Mediador,
            Nome_Locatario, CPF_Locatario, Email_Locatario, Telefone_Locatario,
            CEP_Locatario, Logradouro_Locatario, Numero_Logradouro_Locatario,
            Complemento_Logradouro_Locatario, Cidade_Locatario, Estado_Locatario,
            Score, Pendencia_Financeira, Nome_Locador, CPF_Locador, Email_Locador,
            Telefone_Locador, CEP_Locador, Logradouro_Locador, Numero_Logradouro_Locador,
            Complemento_Logradouro_Locador, Cidade_Locador, Estado_Locador, Tipo_Seguro,
            Apolice_Anterior, tipo_locacao, CEP_Risco, Logradouro_Risco,
            Numero_Logradouro_Risco, Complemento_Risco, Cidade_Risco, Estado_Risco,
            Data_Inicio_Vigencia, Data_Fim_Vigencia, Periodo, IS_Aluguel, IS_IPTU,
            IS_Condominio, IS_Agua, IS_Energia_Eletrica, IS_Gas, IS_Danos_Imovel,
            IS_Pintura_Interna, IS_Pintura_Externa, IS_Multa_Recisoria, Numero_Cotacao, Status
        ) VALUES (
            :unique_id, :Codigo_Mediador, :Nome_Mediador, :Email_Mediador, :Telefone_Mediador,
            :Nome_Locatario, :CPF_Locatario, :Email_Locatario, :Telefone_Locatario,
            :CEP_Locatario, :Logradouro_Locatario, :Numero_Logradouro_Locatario,
            :Complemento_Logradouro_Locatario, :Cidade_Locatario, :Estado_Locatario,
            :Score, :Pendencia_Financeira, :Nome_Locador, :CPF_Locador, :Email_Locador,
            :Telefone_Locador, :CEP_Locador, :Logradouro_Locador, :Numero_Logradouro_Locador,
            :Complemento_Logradouro_Locador, :Cidade_Locador, :Estado_Locador, :Tipo_Seguro,
            :Apolice_Anterior, :tipo_locacao, :CEP_Risco, :Logradouro_Risco,
            :Numero_Logradouro_Risco, :Complemento_Risco, :Cidade_Risco, :Estado_Risco,
            :Data_Inicio_Vigencia, :Data_Fim_Vigencia, :Periodo, :IS_Aluguel, :IS_IPTU,
            :IS_Condominio, :IS_Agua, :IS_Energia_Eletrica, :IS_Gas, :IS_Danos_Imovel,
            :IS_Pintura_Interna, :IS_Pintura_Externa, :IS_Multa_Recisoria, :unique_id, :Status
        );
        """

        return self.db.execute_write(query, dados)
    

    def listar_cotacoes(self, cod_mediador):
        """
        Retorna as cotações do banco de dados com base nos filtros fornecidos em 'dados'.
        :param dados: Dicionário com os filtros para a consulta (exemplo: {"status": "ativo"}).
        :return: Lista de cotações.
        """
        query = "SELECT * FROM Tabela_Seguros WHERE Codigo_Mediador = ?"

        # Executa a consulta com o parâmetro cod_mediador
        resultados = self.db.execute_read(query, (cod_mediador,))

        # Retorna os dados em formato JSON
        return json.dumps(resultados, ensure_ascii=False, indent=4)
    

    def buscar_cotacao(self, numero_cotacao):
        """
        Retorna um cotacao do banco de dados com base nos filtros fornecidos em 'dados'.
        :param dados: Dicionário com os filtros para a consulta (exemplo: {"status": "ativo"}).
        :return: Lista de cotações.
        """
        query = "SELECT * FROM Tabela_Seguros WHERE Numero_Cotacao = ?"

        # Executa a consulta com o parâmetro cod_mediador
        resultados = self.db.execute_read(query, (numero_cotacao,))

        # Retorna os dados em formato JSON
        return resultados