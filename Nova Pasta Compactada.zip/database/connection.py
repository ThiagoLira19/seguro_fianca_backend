import sqlite3

class DatabaseConnection:
    def __init__(self, db_path):
        """
        Inicializa a conexão com o banco de dados.
        :param db_path: Caminho para o arquivo do banco de dados SQLite.
        """
        self.db_path = db_path

    def connect(self):
        """
        Cria e retorna uma conexão com o banco de dados.
        """
        try:
            conn = sqlite3.connect(self.db_path)
            return conn
        except sqlite3.Error as e:
            print(f"Erro ao conectar ao banco de dados: {e}")
            return None

    def execute_write(self, query, params=None):
        """
        Executa uma consulta de escrita (INSERT, UPDATE, DELETE).
        :param query: A consulta SQL a ser executada.
        :param params: Parâmetros para a consulta (opcional).
        :return: Dicionário com o status da operação.
        """
        try:
            conn = self.connect()
            if conn:
                cursor = conn.cursor()
                if params:
                    cursor.execute(query, params)
                    query_update = """
                        UPDATE Tabela_Seguros
                        SET Numero_Cotacao = CAST(last_insert_rowid() AS TEXT) || SUBSTR(STRFTIME('%s', 'now'), -6)
                        WHERE rowid = last_insert_rowid();
                    """
                    cursor.execute(query_update)
                else:
                    cursor.execute(query)
                conn.commit()
                return {"success": True, "message": "Operação executada com sucesso."}
        except sqlite3.Error as e:
            return {"success": False, "message": f"Erro ao executar a consulta: {e}"}
        finally:
            if conn:
                conn.close()

    def execute_read(self, query, params=None):
        """
        Executa uma consulta de leitura (SELECT).
        :param query: A consulta SQL a ser executada.
        :param params: Parâmetros para a consulta (opcional).
        :return: Dicionário com o status da operação e os resultados.
        """
        try:
            conn = self.connect()
            if conn:
                cursor = conn.cursor()
                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)

                # Obtém os nomes das colunas
                colunas = [desc[0] for desc in cursor.description]

                resultados = cursor.fetchall()

                # Converte os resultados para uma lista de dicionários
                cotacoes = [dict(zip(colunas, row)) for row in resultados]

                return cotacoes
            
        except sqlite3.Error as e:
            return {"success": False, "message": f"Erro ao executar a consulta: {e}"}
        finally:
            if conn:
                conn.close()